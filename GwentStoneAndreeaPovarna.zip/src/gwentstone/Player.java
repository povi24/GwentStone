package gwentstone;

public class Player {
    /**
     * Object for initializing the start of the game
     */
    private StartingTheGame game;
    /**
     * The mana each player has, that he gains at the start of a new round
     */
    private int mana;
    /**
     * Number of decks assigned for each player
     */
    private int numberOfDecks;

}
