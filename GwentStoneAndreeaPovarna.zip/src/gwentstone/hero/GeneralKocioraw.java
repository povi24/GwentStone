package gwentstone.hero;

import fileio.CardInput;

public class GeneralKocioraw extends Hero {
    public GeneralKocioraw(final CardInput card) {
        super(card);
        setHealth(30);
    }
}
