package gwentstone.hero;

import fileio.CardInput;

public class LordRoyce extends Hero {
    public LordRoyce(final CardInput card) {
        super(card);
        setHealth(30);
    }
}
