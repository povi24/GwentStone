package gwentstone.hero;

import fileio.CardInput;

public class EmpressThorina extends Hero {
    public EmpressThorina(final CardInput card) {
        super(card);
        setHealth(30);
    }
}
