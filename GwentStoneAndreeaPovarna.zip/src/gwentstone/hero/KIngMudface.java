package gwentstone.hero;

import fileio.CardInput;

public class KIngMudface extends Hero {
    public KIngMudface(final CardInput card) {
        super(card);
        setHealth(30);
    }

}
