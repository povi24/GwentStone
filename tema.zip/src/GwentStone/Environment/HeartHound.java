package GwentStone.Environment;

import fileio.CardInput;

import java.util.ArrayList;

public class HeartHound extends Environment {
//    public HeartHound(int MANA, String Description, ArrayList<String> Colors, String Name) {
//        super(MANA, Description, Colors, Name);
//    }

    public HeartHound(CardInput card) {
        super(card);
    }
}
