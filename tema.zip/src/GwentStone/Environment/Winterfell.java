package GwentStone.Environment;

import fileio.CardInput;

import java.util.ArrayList;

public class Winterfell extends Environment{
//    public Winterfell(int MANA, String Description, ArrayList<String> Colors, String Name) {
//        super(MANA, Description, Colors, Name);
//    }

    public Winterfell(CardInput card) {
        super(card);
    }
}
