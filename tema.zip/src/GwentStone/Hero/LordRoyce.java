package GwentStone.Hero;

import fileio.CardInput;

import java.util.ArrayList;

public class LordRoyce extends Hero{
//    public LordRoyce(String Name, int MANA, String Description, ArrayList<String> Colors) {
//        super(Name, MANA, Description, Colors);
//    }

    public LordRoyce (CardInput card) {
        super(card);
    }
}
