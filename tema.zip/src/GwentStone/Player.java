package GwentStone;

public class Player {

    StartingTheGame game;

    /**
     * The mana each player has, that he gains at the start of a new round
     */
    private int mana;

    private int numberOfDecks;

}
